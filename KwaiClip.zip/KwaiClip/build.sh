#!/usr/bin/env bash
# 任意装有 Docker 的机器一键出 APK（云主机、家里电脑、公司服务器都行）
#
#   chmod +x build.sh && ./build.sh
#
# 产物：app/build/outputs/apk/debug/app-debug.apk
set -euo pipefail

IMAGE="kwaiclip-builder:1.0"
CONTAINER="kwaiclip-build"
PROJECT_DIR="$(cd "$(dirname "$0")" && pwd)"

echo "==> 构建镜像（首次约 3-5 分钟，之后走缓存）"
docker build -t "$IMAGE" -f "$PROJECT_DIR/docker/Dockerfile" "$PROJECT_DIR/docker"

echo "==> 启动容器"
docker rm -f "$CONTAINER" >/dev/null 2>&1 || true
docker run -d --name "$CONTAINER" \
  -v "$PROJECT_DIR":/workspace \
  -v "kwaiclip-gradle":/root/.gradle \
  "$IMAGE" sleep infinity

echo "==> 生成 Gradle Wrapper"
docker exec "$CONTAINER" bash -lc \
  'gradle wrapper --gradle-version 8.7 --distribution-type bin && chmod +x gradlew'

echo "==> 编译 Debug APK"
docker exec "$CONTAINER" bash -lc \
  './gradlew assembleDebug --no-daemon --stacktrace'

echo "==> 完成，产物在："
ls -lh "$PROJECT_DIR"/app/build/outputs/apk/debug/*.apk

docker rm -f "$CONTAINER" >/dev/null 2>&1 || true
