# 快手留痕（KwaiClip）

无 Root、不切界面，给快手加一个"把当前视频存下来"的入口。

## 它做什么

在快手界面常驻一个**悬浮球**。你在快手点「复制链接」后，点一下悬浮球，App 就把这条视频的信息存进本地数据库；可开启"自动模式"，连悬浮球都不用点——监听到你点了「复制链接」就自动保存。

全程不离开快手界面，不读快手私有目录，不 Hook，不抓包。

## 原理（关键一步）

Android 10+ 规定：**只有当前获得输入焦点的 App 才能读剪贴板**。后台服务、前台服务都不行。

破解办法是"抢一下焦点"：

```
悬浮球平时 FLAG_NOT_FOCUSABLE   → 不打扰快手，但读不了剪贴板
点击瞬间清掉该 flag 拿到焦点     → getPrimaryClip() 读到快手链接
读完立刻恢复 flag               → 焦点还给快手
```

悬浮窗用 `TYPE_ACCESSIBILITY_OVERLAY`（无障碍服务专用窗口类型），它能获取焦点，且不需要"显示在其他应用上层"权限。

## 能拿到哪些字段

| 字段 | 稳定性 | 来源 |
|---|---|---|
| 观看时间 | 稳定 | App 自己记录 |
| 视频地址 | 稳定 | 快手「复制链接」写入剪贴板 |
| 视频标题/文案 | 稳定 | 分享文本 |
| 视频 ID | 稳定 | URL 解析 |
| 作者昵称 | 看配置 | 需解析接口或网页抓取 |
| 作者 ID | 看配置 | 同上 |
| 主页地址 | 看配置 | 拼 `https://www.kuaishou.com/profile/{作者ID}` |
| 视频封面 | 看配置 | og:image 或解析接口 |
| 作者头像 | 看配置 | 解析接口 |

作者/封面/头像属于"快手没有对个人开发者开放"的数据。本工程提供两条 best-effort 路径：

1. **网页抓取**：跟随短链重定向后抓 og 标签；
2. **自建/第三方解析接口**：在 App 主界面填入形如 `https://your.host/api?url={url}` 的地址，返回 JSON 即可，字段按常见命名逐一尝试（`nickname`/`name`/`cover`/`avatar`/`user_id`…）。

解析失败也不会丢记录——链接、标题、时间、videoId 一定入库。

## 使用步骤

1. 安装 APK，打开 App，点 **开启无障碍服务** → 在系统无障碍设置里找到「快手留痕」并打开。
2. 回 App，确认「悬浮球：开」。悬浮球可拖动，位置会自动记住。
3. 打开快手，刷到想存的视频 → 点「分享 → 复制链接」。
4. 点悬浮球 → 提示"已保存"。
5. 想更省事：把「自动」开关打开，之后只点「复制链接」就会自动保存。
6. 主界面可查看列表、删除单条、导出 JSON / CSV。

> **自动模式说明**：快手面板里的第一屏就有「复制链接」，不必点「更多」去找系统分享。

## 云端构建（不用装 Android Studio）

### 最省事的一条路：手机上传一个压缩包 → 直接装 APK

**全程手机浏览器就能完成**，不用电脑、不用 git、不用解压、不用登录下载。

1. 手机浏览器打开 github.com，注册/登录，点右上角 **+ → New repository**，随便起个名，勾上 Public，创建
2. 进仓库，点 **Add file → Create new file**，文件名框里填：
   ```
   .github/workflows/build.yml
   ```
   （GitHub 会自动创建多级目录），内容粘贴下面的 [Workflow 文件内容](#workflow-文件内容)，点 Commit
3. 再点 **Add file → Upload files**，把 **`KwaiClip.zip`** 这一个文件传上去，提交
4. 等 5–10 分钟（不用盯着）
5. 打开 `https://github.com/你的用户名/仓库名/releases/latest`，页面最下面的 **Assets** 里点 `app-debug.apk` → 下载 → 直接安装

Workflow 里已内置「自动解压 zip」逻辑，所以只传压缩包就行，不用逐个上传 40 多个文件。

> **为什么不能只传一个文件**：GitHub Actions 的 workflow 必须在仓库的 `.github/workflows/` 路径下才会生效，藏在 zip 里不会被识别。所以最少两步——先放 workflow，再传 zip。这已经是手机上最快的路子了。
>
> **为什么不从 Artifacts 下载**：Artifacts 必须登录 GitHub、下载的是 zip 包、还得解压、7–30 天就过期。Release 里的就是 .apk 文件本身，免登录、长期有效、手机上点一下就装。

> 电脑上操作更简单：装了 git 的话，`git push` 一次就把整个工程（含 workflow）传上去，什么都不用手动创建。

#### Workflow 文件内容

<details>
<summary>点开复制（就是工程里的 <code>.github/workflows/build.yml</code>）</summary>

```yaml
name: Build APK

on:
  push:
    branches: [ main, master ]
  workflow_dispatch:

jobs:
  build:
    runs-on: ubuntu-latest
    # 关键：没有它，发布 Release 会 403
    permissions:
      contents: write

    steps:
      - name: 检出源码
        uses: actions/checkout@v5

      - name: 安装 JDK 17
        uses: actions/setup-java@v5
        with:
          distribution: temurin
          java-version: 17
          cache: gradle

      # 注意：不要加 android-actions/setup-android
      # GitHub runner 已预装 Android SDK，加上反而会因 Node 版本问题失败

      # 支持两种用法：
      #   A) 直接把工程文件传到仓库根目录 -> 跳过解压
      #   B) 只传一个 .zip 源码包        -> 自动解压后再构建
      - name: 准备源码（压缩包会自动解压）
        run: |
          set -e
          if [ -f settings.gradle.kts ]; then
            echo "仓库根目录已有源码，跳过解压"
          else
            shopt -s nullglob
            zips=(*.zip)
            if [ ${#zips[@]} -eq 0 ]; then
              echo "::error::既没有源码文件，也没有 .zip 压缩包"
              exit 1
            fi
            mkdir -p __unzip
            for z in "${zips[@]}"; do
              echo "解压 $z"
              unzip -q -o "$z" -d __unzip
            done
            ROOT=$(find __unzip -name settings.gradle.kts -printf '%h\n' | head -1)
            if [ -z "$ROOT" ]; then
              echo "::error::压缩包里找不到 settings.gradle.kts"
              exit 1
            fi
            cp -a "$ROOT"/. ./
            rm -rf __unzip
            echo "已从压缩包解压源码：$ROOT"
          fi
          ls -a

      - name: 生成 Gradle Wrapper
        run: |
          gradle wrapper --gradle-version 8.7 --distribution-type bin
          chmod +x gradlew

      - name: 构建 Debug APK
        run: ./gradlew assembleDebug --no-daemon --stacktrace

      - name: 上传到 Artifacts
        uses: actions/upload-artifact@v4
        with:
          name: KwaiClip-debug
          path: app/build/outputs/apk/debug/*.apk
          retention-days: 30

      # 重点：Release 里的 APK 是 .apk 文件本身，手机点开就能下载安装
      # 比 Artifacts（要登录 + 解压 zip）方便得多
      - name: 发布到 Release
        uses: softprops/action-gh-release@v2
        with:
          tag_name: build-${{ github.run_number }}
          name: 快手留痕 ${{ github.run_number }}
          body: |
            自动构建的 Debug 版 APK，下载后直接安装即可使用。

            使用步骤：
            1. 安装 APK，打开 App，点「开启无障碍服务」
            2. 在系统无障碍设置里找到「快手留痕」并打开
            3. 打开快手，点「分享 → 复制链接」，再点悬浮球即可保存
          files: app/build/outputs/apk/debug/*.apk
```

</details>

### 想改代码反复调试：GitHub Codespaces

浏览器里一个现成的开发环境，不用 push 等 CI，改完直接在终端跑命令。

1. 仓库页面点 **<> Code → Codespaces → Create codespace on main**
2. 等环境起来（工程已内置 `.devcontainer/devcontainer.json`，JDK 17 + Android SDK 34 会自动装好）
3. 终端里跑 `./gradlew assembleDebug`
4. 左侧文件树找到 `app/build/outputs/apk/debug/app-debug.apk`，右键 **Download**

**免费额度**：个人免费账户每月 120 核心小时 + 15GB 存储（2 核机器约 60 小时/月）。月底重置。用完需要绑卡才能继续。

缺点是手机上操作 VS Code 体验很别扭，适合在电脑上用。

### 其他平台

工程里还备了 `.cnb.yml`（腾讯云 CNB）、`.workflow/build-apk.yml`（码云 Gitee Go）、`.flow.yml`（阿里云云效）、`build.sh` + `docker/`（Docker 一键构建）。选用方式见各自说明。

#### 腾讯云 CNB（国内推荐）

`cnb.cool`，腾讯的云原生构建，国内直连、微信扫码登录，不用梯子。

1. 注册 cnb.cool，新建仓库，把源码推上去
2. 仓库根目录已有 `.cnb.yml`，push 到 `main` 自动触发
3. 在仓库的构建页面看日志、下载产物

**免费额度**：构建 CPU 160 核时/月。配置里声明的是 8 核，约合 20 小时/月；想省额度把 `cpus: 8` 改成 4（慢些但时长翻倍）。月底清零不累计。

#### 码云 Gitee Go

国内速度快，有**现成的 Android 构建模板**，不用自己装 SDK。

1. gitee.com 新建仓库并推送源码
2. 仓库 → **Gitee Go** → 构建流水线 → 新建 → 选「Android 构建」模板
3. 构建工具选 `gradle`，JDK 版本选 **openjdk-17**（AGP 8.5 要求 JDK 17，选 11 会失败）
4. 跑完在「制品」页下载 APK

`.workflow/build-apk.yml` 已备好。免费版算力弱，构建偏慢。

#### Docker 一键构建（最可控）

任何装了 Docker 的机器都行——闲置电脑、云主机、公司服务器，不依赖任何平台额度。

```bash
chmod +x build.sh && ./build.sh
```

脚本会构建 `docker/Dockerfile`（JDK 17 + Android SDK 34 预装），Gradle 缓存用命名卷持久化，第二次快很多。产物：

```
app/build/outputs/apk/debug/app-debug.apk
```

#### 其他平台

| 平台 | 说明 |
|---|---|
| GitLab CI | 自带 Android SDK 镜像，用 `cache: keys` 缓存 Gradle |
| 阿里云云效 Flow | 国内，`.flow.yml` 已备好（通用脚本版） |
| CircleCI | 用 `cimg/android` 镜像，配置简单 |
| Bitrise | 移动专项、可视化编排；免费 300 分钟/月，偏紧 |
| Codemagic | **注意坑**：免费 500 分钟仅限 macOS M2 机器，Linux/Windows 构建不给免费额度。原生 Android 一般用 Linux 构建，所以这 500 分钟基本用不上 |

通用命令都一样：

```bash
gradle wrapper --gradle-version 8.7 --distribution-type bin
./gradlew assembleDebug
```

#### 本地直接构建

装好 JDK 17 + Android SDK（platform 34、build-tools 34）后：

```bash
gradle wrapper --gradle-version 8.7 --distribution-type bin
./gradlew assembleDebug
```

### 构建常见坑

| 现象 | 原因 | 解决 |
|---|---|---|
| Release 创建失败 403 | workflow 缺写权限 | 加 `permissions: contents: write` |
| 加了 setup-android 反而失败 | runner 已预装 SDK，该 action 因 Node 版本报错 | 不要加，只用 setup-java |
| Gradle 版本报错 | runner 预装 Gradle 9.x，与 AGP 8.5 不兼容 | 用官方 wrapper 锁 8.7，别让 gradlew 调系统 Gradle |
| AndroidX 未开启报错 | 缺 gradle.properties | 已配好 `android.useAndroidX=true` |
| JDK 版本不对 | AGP 8.5 需要 JDK 17 | 平台选 openjdk-17 |

> Firebase Studio / Android Studio Cloud 已于 2026 年 6 月停止新用户注册，2027 年 3 月关停，别再按老教程用了。

## 常见问题

**Q：Android 12+ 提示"XX 已读取剪贴板"**
系统行为，去掉不了。这正是它在保护你——本 App 只在你点悬浮球那一瞬间读一次。

**Q：点了悬浮球，快手卡了一下 / 暂停了**
抢焦点的那几十毫秒造成的，多数机型无感。这是无 Root 方案必须付的代价。

**Q：读到的是旧链接**
先确认在快手点了「复制链接」，且提示"已复制"。部分 ROM 会在复制后延迟写入。

**Q：MIUI / ColorOS / vivo 上悬浮球不显示或服务被杀**
国产 ROM 后台限制严格。需要：设置 → 应用 → 快手留痕 → 自启动 + 后台运行（允许后台高耗电）+ 锁定多任务卡片 + 关闭电池优化。

**Q：快手改版，自动模式不触发了**
自动模式依赖"复制链接"这几个字的界面文案。若失效，改 `KwaiBallService.onAccessibilityEvent()` 里的匹配词，或直接用手动点悬浮球。

**Q：为什么不做成后台自动记录所有观看历史**
Android 10+ 封死了后台剪贴板访问，无 Root 做不到，Root 之外没有合规途径。本 App 只做"你主动操作时的记录"。

## 查看界面

主界面就是历史记录页，做成快手那种样式：

- **两列网格**，卡片高度 210dp，接近短视频封面的 3:4 比例
- **按自然日分组**：今天 / 昨天 / M月d日 / 跨年显示 YYYY年M月d日，每组带条数
- **组内按观看时间降序**，最新的排最前
- **封面上叠加作者**：底部渐变遮罩 + 圆形头像 + 昵称，右下角显示 HH:mm
- 点卡片 → 用浏览器/快手打开原链接；点右上角圆钮 → 删除该条
- 无封面时显示占位图，无头像时显示橙色圆形占位
- 还没有记录时显示引导文案

实现上用单一 `ListAdapter` + 两种 viewType（日期头 / 视频卡片），配合 `GridLayoutManager.SpanSizeLookup` 让日期头占满整行、卡片占 1 列。

## 目录结构

```
app/src/main/java/com/yuanbao/kwaiclip/
├── MainActivity.kt       主界面：开关、历史记录网格、导出
├── KwaiBallService.kt    核心：无障碍悬浮球 + 抢焦点读剪贴板
├── ShareSaveActivity.kt  兜底：系统分享入口
├── ClipParser.kt         快手分享文本解析
├── DetailResolver.kt     详情补全（短链展开 / 解析接口 / og 抓取）
├── ClipRepository.kt     保存逻辑（去重 + 入库 + 补全）
├── RecordAdapter.kt      分组网格适配器（日期头 + 卡片，Coil 圆角/圆形裁剪）
├── Prefs.kt              开关与配置
└── data/Db.kt            Room 数据库（8 字段 + 原始文本）
```

## 声明

仅供个人记录自己的观看内容使用。数据全部存在本机，不上传任何服务器（除非你自己在设置里填了外部解析接口，此时链接会被发送到该接口）。
