package com.yuanbao.kwaiclip

import android.accessibilityservice.AccessibilityService
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.ClipboardManager
import android.content.Context
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewTreeObserver
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.Toast
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.abs

/**
 * 核心：无障碍服务 + TYPE_ACCESSIBILITY_OVERLAY 悬浮球 + 「抢焦点读剪贴板」。
 *
 * 关键点（Android 10+ 后台读不到剪贴板）：
 *   悬浮球平时 FLAG_NOT_FOCUSABLE（不打扰快手）；
 *   点击瞬间清掉该 flag 抢到焦点 -> 读剪贴板 -> 立刻还回焦点。
 */
class KwaiBallService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: KwaiBallService? = null
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val handler by lazy { Handler(Looper.getMainLooper()) }

    private lateinit var wm: WindowManager
    private lateinit var lp: WindowManager.LayoutParams
    private var ball: View? = null
    private var added = false

    override fun onServiceConnected() {
        instance = this
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        notifyRunning()
        refreshBall()
    }

    override fun onDestroy() {
        removeBall()
        instance = null
        scope.cancel()
        super.onDestroy()
    }

    override fun onInterrupt() {}

    // ---------- 自动模式：监听到「复制链接」被点击就自动保存 ----------
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (!Prefs.autoEnabled(this)) return
        val e = event ?: return
        if (e.eventType != AccessibilityEvent.TYPE_VIEW_CLICKED) return
        val txt = e.text?.joinToString("") ?: return
        val hit = txt.contains("复制链接") || txt.contains("复制链") ||
            txt.contains("复制此链接") || txt.contains("分享链接")
        if (!hit) return
        // 等快手把链接写进剪贴板
        handler.postDelayed({ readClipboardWithFocus { handleText(it) } }, 700)
    }

    // ---------- 悬浮球 ----------
    fun refreshBall() {
        handler.post {
            if (Prefs.ballEnabled(this)) addBall() else removeBall()
        }
    }

    private fun addBall() {
        if (added) return
        val v = LayoutInflater.from(this).inflate(R.layout.ball, null)
        val p = Prefs.sp(this)
        // 必须给窗口固定像素尺寸：WRAP_CONTENT 遇到子 View 的 match_parent
        // 会被撑满整个屏幕。getDimensionPixelSize 让系统把 dp 换算成像素。
        val size = resources.getDimensionPixelSize(R.dimen.ball_size)
        lp = WindowManager.LayoutParams(
            size,
            size,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,   // 平时不抢焦点
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = p.getInt(Prefs.KEY_X, 40)
            y = p.getInt(Prefs.KEY_Y, 300)
        }
        runCatching { wm.addView(v, lp) }.onFailure { return }
        ball = v
        added = true
        attachTouch(v)
        v.setOnClickListener { readClipboardWithFocus { handleText(it) } }
    }

    private fun removeBall() {
        if (!added) return
        runCatching { wm.removeView(ball) }
        ball = null
        added = false
    }

    private fun attachTouch(v: View) {
        var sx = 0f
        var sy = 0f
        var lx = 0
        var ly = 0
        var moved = false
        v.setOnTouchListener { view, ev ->
            when (ev.action) {
                MotionEvent.ACTION_DOWN -> {
                    sx = ev.rawX; sy = ev.rawY; lx = lp.x; ly = lp.y; moved = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (ev.rawX - sx).toInt()
                    val dy = (ev.rawY - sy).toInt()
                    if (abs(dx) > 8 || abs(dy) > 8) moved = true
                    lp.x = lx + dx
                    lp.y = ly + dy
                    runCatching { wm.updateViewLayout(view, lp) }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) view.performClick()
                    else Prefs.sp(this).edit()
                        .putInt(Prefs.KEY_X, lp.x)
                        .putInt(Prefs.KEY_Y, lp.y)
                        .apply()
                    true
                }
                else -> false
            }
        }
    }

    // ---------- 抢焦点读剪贴板 ----------
    private fun readClipboardWithFocus(onText: (String?) -> Unit) {
        val view = ball
        if (view == null) {
            // 自动模式下可能没有悬浮球，退化为直接读（有焦点时才有值）
            onText(readClip())
            return
        }
        // 先给个即时反馈，确保用户知道点到了（哪怕后面读剪贴板失败）
        notifyResult("正在读取剪贴板…")

        val done = AtomicBoolean(false)
        val finish: (String?) -> Unit = { text ->
            if (done.compareAndSet(false, true)) {
                restoreNoFocus()
                onText(text)
            }
        }

        lp.flags = lp.flags and WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE.inv()
        runCatching { wm.updateViewLayout(view, lp) }
        view.requestFocus()

        val listener = object : ViewTreeObserver.OnWindowFocusChangeListener {
            override fun onWindowFocusChanged(hasFocus: Boolean) {
                if (!hasFocus) return
                // 焦点到达后等一拍再读，给系统写入剪贴板的时间
                handler.postDelayed({ finish(readClip()) }, 120)
            }
        }
        view.viewTreeObserver.addOnWindowFocusChangeListener(listener)
        // 兜底：无论是否收到 focus 回调，都尝试读一次，保证一定有反馈
        handler.postDelayed({
            runCatching { view.viewTreeObserver.removeOnWindowFocusChangeListener(listener) }
            finish(readClip())
        }, 700)
    }

    private fun restoreNoFocus() {
        val view = ball ?: return
        lp.flags = lp.flags or WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
        runCatching { wm.updateViewLayout(view, lp) }
    }

    private fun readClip(): String? = runCatching {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.primaryClip?.getItemAt(0)?.coerceToText(this)?.toString()
    }.getOrNull()

    // ---------- 保存 ----------
    private fun handleText(text: String?) {
        if (text.isNullOrBlank()) {
            feedback("没读到剪贴板内容")
            return
        }
        scope.launch {
            val (ok, msg) = ClipRepository.save(this@KwaiBallService, text)
            withContext(Dispatchers.Main) {
                feedback(if (ok) "已保存：$msg" else msg)
            }
        }
    }

    /** Toast + 通知栏双通道，避免某些 ROM 吞掉 Toast 后完全看不到反馈 */
    private fun feedback(msg: String) {
        handler.post {
            runCatching { Toast.makeText(this, msg, Toast.LENGTH_LONG).show() }
        }
        notifyResult(msg)
    }

    private fun toast(msg: String) = feedback(msg)

    // ---------- 常驻通知 ----------
    private fun notifyRunning() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            nm.createNotificationChannel(
                NotificationChannel("kwai_clip", "快手留痕运行", NotificationManager.IMPORTANCE_LOW)
            )
        }
        runCatching { nm.notify(1001, runningNotification(null)) }
    }

    /** 与常驻通知同 ID 更新，把最新结果直接显示在通知栏上 */
    private fun notifyResult(msg: String) {
        runCatching {
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.notify(1001, runningNotification(msg))
        }
    }

    private fun runningNotification(msg: String?): android.app.Notification {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            runCatching {
                (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager)
                    .createNotificationChannel(
                        NotificationChannel("kwai_clip", "快手留痕运行", NotificationManager.IMPORTANCE_LOW)
                    )
            }
        }
        return NotificationCompat.Builder(this, "kwai_clip")
            .setContentTitle("快手留痕")
            .setContentText(msg ?: "在快手点「复制链接」后点悬浮球即可保存")
            .setSmallIcon(R.mipmap.ic_launcher)
            .setOngoing(true)
            .build()
    }
}
