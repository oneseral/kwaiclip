package com.yuanbao.kwaiclip

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * 兜底入口：快手分享面板 -> 更多 -> 系统分享 -> 选「存快手」。
 * 不依赖无障碍服务；Android 10+ 需等窗口拿到焦点才能读，故这里既监听焦点变化，也留了兜底延时。
 */
class ShareSaveActivity : ComponentActivity() {

    private var text: String? = null
    private var handled = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        text = intent?.getStringExtra(Intent.EXTRA_TEXT)
            ?: intent?.getCharSequenceExtra(Intent.EXTRA_TEXT)?.toString()
            ?: intent?.getCharSequenceExtra(Intent.EXTRA_PROCESS_TEXT)?.toString()

        if (text.isNullOrBlank()) {
            finish()
            return
        }
        // 兜底：万一焦点回调没来，800ms 后照样处理一次
        Handler(Looper.getMainLooper()).postDelayed({ handle() }, 800)
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) handle()
    }

    private fun handle() {
        if (handled) return
        handled = true
        val t = text ?: run { finish(); return }
        lifecycleScope.launch {
            val (ok, msg) = withContext(Dispatchers.IO) {
                ClipRepository.save(this@ShareSaveActivity, t)
            }
            Toast.makeText(this@ShareSaveActivity, if (ok) "已保存：$msg" else msg, Toast.LENGTH_SHORT).show()
            finish()
        }
    }
}
