package com.yuanbao.kwaiclip

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import coil.load
import coil.transform.CircleCropTransformation
import coil.transform.RoundedCornersTransformation
import com.yuanbao.kwaiclip.data.Record
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/** 列表行：日期分组头 + 视频卡片 */
sealed class Row {
    data class Header(val key: String, val label: String, val count: Int) : Row()
    data class Item(val record: Record) : Row()
}

class RecordAdapter(
    private val onDelete: (Record) -> Unit,
    private val onItemClick: (Record) -> Unit = {}
) : ListAdapter<Row, RecyclerView.ViewHolder>(Diff) {

    companion object {
        const val TYPE_HEADER = 0
        const val TYPE_ITEM = 1
        const val SPAN_COUNT = 2
    }

    object Diff : DiffUtil.ItemCallback<Row>() {
        override fun areItemsTheSame(a: Row, b: Row) = when {
            a is Row.Header && b is Row.Header -> a.key == b.key
            a is Row.Item && b is Row.Item -> a.record.id == b.record.id
            else -> false
        }

        override fun areContentsTheSame(a: Row, b: Row) = a == b
    }

    /** 按观看时间降序 → 按自然日分组 → 摊平成 [日期头, 卡片…] */
    fun submitRecords(list: List<Record>) {
        val fmtKey = SimpleDateFormat("yyyy-MM-dd", Locale.CHINA)
        val groups = linkedMapOf<String, MutableList<Record>>()
        list.sortedByDescending { it.watchTime }.forEach { r ->
            groups.getOrPut(fmtKey.format(Date(r.watchTime))) { mutableListOf() }.add(r)
        }
        val rows = mutableListOf<Row>()
        groups.forEach { (key, items) ->
            rows.add(Row.Header(key, dayLabel(key), items.size))
            items.forEach { rows.add(Row.Item(it)) }
        }
        submitList(rows)
    }

    override fun getItemViewType(pos: Int) =
        if (getItem(pos) is Row.Header) TYPE_HEADER else TYPE_ITEM

    class HeaderHolder(v: View) : RecyclerView.ViewHolder(v) {
        val date: TextView = v.findViewById(R.id.tvDate)
        val count: TextView = v.findViewById(R.id.tvCount)
    }

    class ItemHolder(v: View) : RecyclerView.ViewHolder(v) {
        val cover: ImageView = v.findViewById(R.id.imgCover)
        val avatar: ImageView = v.findViewById(R.id.imgAvatar)
        val author: TextView = v.findViewById(R.id.tvAuthor)
        val time: TextView = v.findViewById(R.id.tvTime)
        val del: ImageButton = v.findViewById(R.id.btnDelete)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val inf = LayoutInflater.from(parent.context)
        return if (viewType == TYPE_HEADER)
            HeaderHolder(inf.inflate(R.layout.item_date_header, parent, false))
        else
            ItemHolder(inf.inflate(R.layout.item_record, parent, false))
    }

    override fun onBindViewHolder(h: RecyclerView.ViewHolder, pos: Int) {
        when (val row = getItem(pos)) {
            is Row.Header -> {
                h as HeaderHolder
                h.date.text = row.label
                h.count.text = "${row.count} 条"
            }
            is Row.Item -> {
                h as ItemHolder
                val r = row.record
                h.time.text = SimpleDateFormat("HH:mm", Locale.CHINA).format(Date(r.watchTime))
                h.author.text = r.authorName.ifBlank { "未知作者" }

                // 封面：无 URL 时显示占位
                if (r.coverUrl.isBlank()) {
                    h.cover.load(R.drawable.ic_placeholder)
                } else {
                    h.cover.load(r.coverUrl) {
                        crossfade(true)
                        placeholder(R.drawable.bg_cover_placeholder)
                        error(R.drawable.ic_placeholder)
                        transformations(RoundedCornersTransformation(28f))
                    }
                }

                // 头像：圆形裁剪，无 URL 时显示橙色圆形占位
                if (r.avatarUrl.isBlank()) {
                    h.avatar.setImageResource(R.drawable.bg_avatar_circle)
                } else {
                    h.avatar.load(r.avatarUrl) {
                        crossfade(true)
                        placeholder(R.drawable.bg_avatar_circle)
                        error(R.drawable.bg_avatar_circle)
                        transformations(CircleCropTransformation())
                    }
                }

                h.del.setOnClickListener { onDelete(r) }
                h.itemView.setOnClickListener { onItemClick(r) }
            }
        }
    }
}

fun formatTime(ms: Long): String =
    SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.CHINA).format(Date(ms))

/** 今天 / 昨天 / M月d日 / YYYY年M月d日 */
private fun dayLabel(key: String): String {
    val fmtKey = SimpleDateFormat("yyyy-MM-dd", Locale.CHINA)
    val today = fmtKey.format(Date())
    val cal = Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, -1) }
    val yesterday = fmtKey.format(cal.time)
    return when (key) {
        today -> "今天"
        yesterday -> "昨天"
        else -> {
            val d = runCatching { fmtKey.parse(key) }.getOrNull() ?: return key
            val now = Calendar.getInstance()
            val c = Calendar.getInstance().apply { time = d }
            if (c.get(Calendar.YEAR) == now.get(Calendar.YEAR))
                SimpleDateFormat("M月d日", Locale.CHINA).format(d)
            else
                SimpleDateFormat("yyyy年M月d日", Locale.CHINA).format(d)
        }
    }
}
