package com.yuanbao.kwaiclip

import android.content.Context
import com.yuanbao.kwaiclip.data.AppDatabase
import com.yuanbao.kwaiclip.data.Record
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Service 与 系统分享入口共用的保存逻辑。
 * @return Pair(是否新保存成功, 提示文案)
 */
object ClipRepository {

    suspend fun save(context: Context, text: String): Pair<Boolean, String> {
        val clip = ClipParser.parse(text)
            ?: return false to "剪贴板里没有快手链接"

        val dao = AppDatabase.get(context).dao()
        if (dao.countByVideoId(clip.videoId) > 0) return false to "这条已经存过了"

        val rec = Record(
            watchTime = System.currentTimeMillis(),
            videoId = clip.videoId,
            videoUrl = clip.url,
            title = clip.title,
            // 分享文本里的【xxx的视频】直接作为作者昵称，解析接口拿到更准的会覆盖
            authorName = clip.authorName,
            rawText = clip.rawText
        )
        if (dao.insert(rec) == -1L) return false to "这条已经存过了"

        // 尽力补全封面 / 头像 / 主页，失败也不影响已保存的记录
        withContext(Dispatchers.IO) {
            runCatching {
                val api = Prefs.apiTemplate(context)
                val d = DetailResolver.resolve(clip.url, api, clip.videoId) ?: return@runCatching
                val saved = dao.findByUrl(clip.url) ?: return@runCatching
                dao.update(
                    saved.copy(
                        videoId = clip.videoId,
                        videoUrl = d.finalUrl.ifBlank { saved.videoUrl },
                        title = d.title.ifBlank { saved.title },
                        authorName = d.authorName.ifBlank { saved.authorName },
                        authorId = d.authorId.ifBlank { saved.authorId },
                        profileUrl = d.profileUrl.ifBlank { saved.profileUrl },
                        coverUrl = d.coverUrl.ifBlank { saved.coverUrl },
                        avatarUrl = d.avatarUrl.ifBlank { saved.avatarUrl }
                    )
                )
            }
        }
        return true to (clip.title.ifBlank { "已保存" })
    }
}
