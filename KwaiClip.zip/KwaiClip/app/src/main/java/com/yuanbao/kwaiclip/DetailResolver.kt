package com.yuanbao.kwaiclip

import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.net.URLEncoder
import java.util.concurrent.TimeUnit

/**
 * 详情补全：把视频短链换成真实信息（标题、封面、作者、头像、主页）。
 *
 * 说明：
 * 1. 短链 -> 长链：跟随 HTTP 重定向即可，稳定。
 * 2. 作者 / 头像 / 主页：快手未对个人开发者开放这类接口，本实现提供两种可选方式：
 *    a) 网页抓取 og 标签（best-effort，可能被风控，失败就留空）；
 *    b) 自建 / 第三方解析接口：在 App 设置里填写带 {url} 占位的地址，返回 JSON 即可，
 *       字段按常见命名逐一尝试（nickname/name/cover/image/avatar/user_id/...）。
 * 3. 无论成功与否，视频地址、标题、观看时间、videoId 一定会被保存。
 */
object DetailResolver {

    private const val PC_UA =
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 " +
            "(KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"

    private val client: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .followRedirects(true)
            .followSslRedirects(true)
            .connectTimeout(15, TimeUnit.SECONDS)
            .readTimeout(20, TimeUnit.SECONDS)
            .build()
    }

    data class Detail(
        var finalUrl: String = "",
        var title: String = "",
        var coverUrl: String = "",
        var authorName: String = "",
        var authorId: String = "",
        var avatarUrl: String = "",
        var profileUrl: String = ""
    ) {
        fun finishProfile() {
            if (profileUrl.isBlank() && authorId.isNotBlank()) {
                profileUrl = "https://www.kuaishou.com/profile/$authorId"
            }
        }
    }

    /** @param apiTemplate 形如 https://your.host/api?url={url} ，可为空 */
    fun resolve(rawUrl: String, apiTemplate: String): Detail? = runCatching {
        val finalUrl = expand(rawUrl) ?: rawUrl
        val d = Detail(finalUrl = finalUrl)
        if (apiTemplate.isNotBlank()) parseApi(apiTemplate, finalUrl, d) else parseWeb(finalUrl, d)
        d.finishProfile()
        d
    }.getOrNull()

    private fun expand(url: String): String? = runCatching {
        client.newCall(
            Request.Builder().url(url).head().header("User-Agent", PC_UA).build()
        ).execute().use { resp ->
            resp.request.url.toString().takeIf { it.isNotBlank() }
        }
    }.getOrNull()

    private fun parseWeb(url: String, d: Detail) {
        val html = runCatching {
            client.newCall(
                Request.Builder().url(url).get().header("User-Agent", PC_UA).build()
            ).execute().use { it.body?.string() }
        }.getOrNull() ?: return

        d.title = meta(html, "og:title")
            .ifBlank { Regex("<title>(.*?)</title>").find(html)?.groupValues?.get(1)?.trim() ?: "" }
        d.coverUrl = meta(html, "og:image")
        d.authorName = meta(html, "og:video:actor").ifBlank { meta(html, "author") }
        d.avatarUrl = meta(html, "og:image").takeIf { it.contains("avatar", true) } ?: ""
        // 主页链接：网页里通常形如 /profile/xxxx
        d.authorId = Regex("/profile/([\\w-]+)").find(html)?.groupValues?.get(1) ?: ""
    }

    private fun meta(html: String, prop: String): String {
        val p1 = Regex(
            "<meta[^>]+(?:property|name)\\s*=\\s*[\"']$prop[\"'][^>]+content\\s*=\\s*[\"']([^\"']*)[\"']",
            RegexOption.IGNORE_CASE
        ).find(html)?.groupValues?.get(1)
        if (!p1.isNullOrBlank()) return p1.trim()
        return Regex(
            "<meta[^>]+content\\s*=\\s*[\"']([^\"']*)[\"'][^>]+(?:property|name)\\s*=\\s*[\"']$prop[\"']",
            RegexOption.IGNORE_CASE
        ).find(html)?.groupValues?.get(1)?.trim() ?: ""
    }

    private fun parseApi(template: String, url: String, d: Detail) {
        val target = template.replace("{url}", URLEncoder.encode(url, "UTF-8"))
        val body = runCatching {
            client.newCall(
                Request.Builder().url(target).get().header("User-Agent", PC_UA).build()
            ).execute().use { it.body?.string() }
        }.getOrNull() ?: return

        val root = runCatching { JSONObject(body) }.getOrNull() ?: return
        val data = root.opt("data") as? JSONObject ?: root
        val node = when {
            data.opt("data") is JSONObject -> data.optJSONObject("data")!!
            data.opt("item") is JSONObject -> data.optJSONObject("item")!!
            else -> data
        }

        d.title = pick(node, "title", "desc", "caption", "description")
        d.coverUrl = pick(node, "cover", "coverUrl", "cover_url", "image", "thumbnail", "poster")
        d.avatarUrl = pick(node, "avatar", "avatarUrl", "avatar_url", "headerUrl", "authorAvatar")
        d.authorName = pick(node, "nickname", "nick", "name", "authorName", "userName", "user_name")
        d.authorId = pick(node, "userId", "user_id", "authorId", "author_id", "uid", "ownerId")
        if (d.authorName.isBlank()) {
            d.authorName = (node.opt("author") as? JSONObject)?.let {
                pick(it, "nickname", "name", "nick")
            } ?: ""
        }
        if (d.avatarUrl.isBlank()) {
            d.avatarUrl = (node.opt("author") as? JSONObject)?.let {
                pick(it, "avatar", "headerUrl", "avatarUrl")
            } ?: ""
        }
    }

    private fun pick(o: JSONObject, vararg keys: String): String {
        for (k in keys) {
            val v = o.optString(k, "")
            if (!v.isNullOrBlank() && v != "null") return v.trim()
        }
        return ""
    }
}
