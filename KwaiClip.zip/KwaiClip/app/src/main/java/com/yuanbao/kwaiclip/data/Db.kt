package com.yuanbao.kwaiclip.data

import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Index
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Entity(
    tableName = "record",
    indices = [Index(value = ["videoUrl"], unique = true)]
)
data class Record(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    /** 观看 / 保存时间，毫秒时间戳 */
    val watchTime: Long = 0,
    /** 视频 ID（短链与长链解析后统一） */
    val videoId: String = "",
    /** 视频地址 */
    val videoUrl: String = "",
    /** 视频标题 / 文案 */
    val title: String = "",
    /** 作者昵称 */
    val authorName: String = "",
    /** 作者 ID */
    val authorId: String = "",
    /** 作者主页地址：https://www.kuaishou.com/profile/{authorId} */
    val profileUrl: String = "",
    /** 视频封面图 URL */
    val coverUrl: String = "",
    /** 作者头像 URL */
    val avatarUrl: String = "",
    /** 快手原始分享文本，便于回溯 */
    val rawText: String = ""
)

@Dao
interface RecordDao {

    @Query("SELECT * FROM record ORDER BY watchTime DESC")
    fun observeAll(): Flow<List<Record>>

    @Query("SELECT * FROM record ORDER BY watchTime DESC")
    suspend fun all(): List<Record>

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insert(r: Record): Long

    @Update
    suspend fun update(r: Record)

    @Query("SELECT COUNT(*) FROM record WHERE videoId = :videoId AND videoId <> ''")
    suspend fun countByVideoId(videoId: String): Int

    @Query("SELECT * FROM record WHERE videoUrl = :url LIMIT 1")
    suspend fun findByUrl(url: String): Record?

    @Query("DELETE FROM record WHERE id = :id")
    suspend fun delete(id: Int)

    @Query("DELETE FROM record")
    suspend fun clear()
}

@Database(entities = [Record::class], version = 1, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {

    abstract fun dao(): RecordDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun get(context: android.content.Context): AppDatabase =
            INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "kwai_clip.db"
                ).fallbackToDestructiveMigration().build().also { INSTANCE = it }
            }
    }
}
