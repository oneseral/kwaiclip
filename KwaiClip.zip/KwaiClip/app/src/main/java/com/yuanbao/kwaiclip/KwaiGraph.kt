package com.yuanbao.kwaiclip

import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.util.concurrent.TimeUnit
import java.util.UUID

/**
 * 内置解析器：直接调快手网页端的视频详情接口，不需要用户自己填解析接口。
 *
 * 接口：POST https://www.kuaishou.com/graphql
 * 操作：visionVideoDetail
 * 条件：需要 did cookie（自己生成一个随机 web_ 前缀的设备号即可），
 *       公开视频通常无需登录态。
 *
 * 注意：这是网页端自用接口，不是快手开放平台的公开 API（开放平台面向
 * 企业/电商/小程序，不提供"查别人视频详情"的能力）。因此稳定性不保证，
 * 快手随时可能加风控；失败时本类返回 null，由 [DetailResolver] 降级到
 * og 标签抓取，绝不影响链接与标题的保存。
 */
object KwaiGraph {

    private const val ENDPOINT = "https://www.kuaishou.com/graphql"
    private const val MOBILE_ENDPOINT = "https://video.kuaishou.com/graphql"

    private const val PC_UA =
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 " +
            "(KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"

    /** 字段按需精简，够用即可，减少被风控的概率 */
    private const val QUERY =
        "query visionVideoDetail(\$photoId: String, \$type: String, \$page: String, \$webPageArea: String) {" +
            "visionVideoDetail(photoId: \$photoId, type: \$type, page: \$page, webPageArea: \$webPageArea) {" +
            "status " +
            "author { id name headerUrl } " +
            "photo { id caption coverUrl photoUrl timestamp } " +
            "}" +
            "}"

    private val client: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .followRedirects(true)
            .followSslRedirects(true)
            .connectTimeout(15, TimeUnit.SECONDS)
            .readTimeout(20, TimeUnit.SECONDS)
            .build()
    }

    /** 随机设备号，形如 web_ 开头 32 位十六进制，与网页端一致 */
    private fun randomDid(): String = "web_" + UUID.randomUUID().toString().replace("-", "")

    private fun cookie(): String =
        "kpf=PC_WEB; kpn=KUAISHOU_VISION; clientid=3; did=${randomDid()}; didv=${System.currentTimeMillis()}"

    /**
     * @param photoId 视频 ID（short-video / f / video 路径后的那一串）
     * @return 解析结果，失败返回 null
     */
    fun fetch(photoId: String): GraphResult? {
        if (photoId.isBlank()) return null
        val body = JSONObject().apply {
            put("operationName", "visionVideoDetail")
            put(
                "variables",
                JSONObject().apply {
                    put("photoId", photoId)
                    put("page", "detail")
                }
            )
            put("query", QUERY)
        }.toString()

        // 主端点失败就换备用端点
        val json = post(ENDPOINT, body, photoId) ?: post(MOBILE_ENDPOINT, body, photoId) ?: return null
        return parse(json)
    }

    private fun post(url: String, body: String, photoId: String): JSONObject? = runCatching {
        val req = Request.Builder()
            .url(url)
            .post(body.toRequestBody("application/json".toMediaType()))
            .header("User-Agent", PC_UA)
            .header("Content-Type", "application/json")
            .header("Origin", "https://www.kuaishou.com")
            .header("Referer", "https://www.kuaishou.com/short-video/$photoId")
            .header("Cookie", cookie())
            .build()
        client.newCall(req).execute().use { resp ->
            if (!resp.isSuccessful) return null
            JSONObject(resp.body?.string() ?: return null)
        }
    }.getOrNull()

    private fun parse(root: JSONObject): GraphResult? {
        val data = root.optJSONObject("data") ?: return null
        val detail = data.optJSONObject("visionVideoDetail") ?: return null
        // status 为 1 表示成功；风控时可能返回别的
        val photo = detail.optJSONObject("photo") ?: return null
        val author = detail.optJSONObject("author")

        val authorId = author?.optString("id", "").orEmpty()
        return GraphResult(
            title = photo.optString("caption", ""),
            coverUrl = photo.optString("coverUrl", ""),
            photoUrl = photo.optString("photoUrl", ""),
            authorId = authorId,
            authorName = author?.optString("name", "").orEmpty(),
            avatarUrl = author?.optString("headerUrl", "").orEmpty(),
            profileUrl = if (authorId.isBlank()) "" else "https://www.kuaishou.com/profile/$authorId"
        )
    }
}

data class GraphResult(
    val title: String,
    val coverUrl: String,
    val photoUrl: String,
    val authorId: String,
    val authorName: String,
    val avatarUrl: String,
    val profileUrl: String
)
