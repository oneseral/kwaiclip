package com.yuanbao.kwaiclip

import android.content.Context

object Prefs {
    const val NAME = "kwai_clip"
    const val KEY_BALL = "ball_enabled"
    const val KEY_AUTO = "auto_copy"
    const val KEY_X = "ball_x"
    const val KEY_Y = "ball_y"
    const val KEY_API = "resolve_api"

    fun sp(context: Context) = context.getSharedPreferences(NAME, Context.MODE_PRIVATE)

    fun ballEnabled(context: Context) = sp(context).getBoolean(KEY_BALL, true)
    fun autoEnabled(context: Context) = sp(context).getBoolean(KEY_AUTO, false)
    fun apiTemplate(context: Context) = sp(context).getString(KEY_API, "") ?: ""
}
