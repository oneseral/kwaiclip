package com.yuanbao.kwaiclip

/**
 * 解析快手分享到剪贴板的文本。
 *
 * 典型文本：
 * 【老李的视频】今天工地吃饭，酸豆角炒肉 https://v.kuaishou.com/AbC123 复制此链接，打开快手App直接观看！
 */
object ClipParser {

    private const val HOST =
        "v\\.kuaishou\\.com|kuaishou\\.com|chenzhongtech\\.com|gifshow\\.com|kwai\\.com"

    private val URL_RE = Regex(
        "https?://(?:[a-z0-9-]+\\.)*(?:$HOST)/[^\\s，,。;；\"'）)】]+",
        RegexOption.IGNORE_CASE
    )

    private val ID_RE = Regex("/(?:short-video|profile|f|s|u)/([\\w-]+)")

    private val NOISE_RE = Regex(
        "复制此(链接|消息|口令).*$|打开快手.*$|长按复制.*$|点击链接.*$|快口令.*$|" +
            "【[^】]*】|\\(来自.*\\)$|——来自快手.*$"
    )

    fun isKuaishou(text: String?): Boolean {
        if (text.isNullOrBlank()) return false
        return URL_RE.containsMatchIn(text)
    }

    /** 从一段文本中解析出视频信息，非快手文本返回 null */
    fun parse(text: String): ParsedClip? {
        val url = URL_RE.find(text)?.value?.trimEnd('.', '，', ',', '。', ')', '）') ?: return null
        val videoId = ID_RE.find(url)?.groupValues?.get(1)
            ?: url.substringAfterLast('/').substringBefore('?').takeIf { it.isNotBlank() }
            ?: url
        val title = text
            .replace(URL_RE, " ")
            .replace(NOISE_RE, " ")
            .replace(Regex("\\s+"), " ")
            .trim()
        val isProfile = url.contains("/profile/") || url.contains("/u/")
        return ParsedClip(url = url, videoId = videoId, title = title, isProfile = isProfile, rawText = text)
    }
}

data class ParsedClip(
    val url: String,
    val videoId: String,
    val title: String,
    val isProfile: Boolean,
    val rawText: String
)
