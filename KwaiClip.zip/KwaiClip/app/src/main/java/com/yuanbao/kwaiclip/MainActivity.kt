package com.yuanbao.kwaiclip

import android.Manifest
import android.accessibilityservice.AccessibilityServiceInfo
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.view.accessibility.AccessibilityManager
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.yuanbao.kwaiclip.data.AppDatabase
import com.yuanbao.kwaiclip.data.Record
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : ComponentActivity() {

    private val dao by lazy { AppDatabase.get(this).dao() }
    private lateinit var adapter: RecordAdapter
    private lateinit var tvStatus: TextView
    private lateinit var tvEmpty: TextView

    private val requestNoti = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { /* 结果忽略，通知失败不影响使用 */ }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        tvStatus = findViewById(R.id.tvStatus)
        tvEmpty = findViewById(R.id.tvEmpty)
        val etApi = findViewById<EditText>(R.id.etApi)
        etApi.setText(Prefs.apiTemplate(this))
        etApi.setOnFocusChangeListener { _, hasFocus ->
            if (!hasFocus) {
                Prefs.sp(this).edit().putString(Prefs.KEY_API, etApi.text.toString().trim()).apply()
            }
        }

        adapter = RecordAdapter(
            onDelete = { r -> lifecycleScope.launch(Dispatchers.IO) { dao.delete(r.id) } },
            onItemClick = { r ->
                runCatching {
                    startActivity(
                        Intent(Intent.ACTION_VIEW, Uri.parse(r.videoUrl.ifBlank { r.profileUrl }))
                    )
                }.onFailure { toast("打不开链接") }
            }
        )
        findViewById<RecyclerView>(R.id.recycler).apply {
            val glm = GridLayoutManager(this@MainActivity, RecordAdapter.SPAN_COUNT)
            glm.spanSizeLookup = object : GridLayoutManager.SpanSizeLookup() {
                override fun getSpanSize(position: Int) =
                    if (adapter?.getItemViewType(position) == RecordAdapter.TYPE_HEADER)
                        RecordAdapter.SPAN_COUNT else 1
            }
            layoutManager = glm
            adapter = this@MainActivity.adapter
            clipToPadding = false
            setPadding(10, 0, 10, 16)
        }

        findViewById<Button>(R.id.btnAccessibility).setOnClickListener {
            askNotificationPermissionIfNeeded()
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }

        val btnBall = findViewById<Button>(R.id.btnBall)
        val btnAuto = findViewById<Button>(R.id.btnAuto)
        fun syncToggles() {
            btnBall.text = "悬浮球：" + if (Prefs.ballEnabled(this)) "开" else "关"
            btnAuto.text = "自动：" + if (Prefs.autoEnabled(this)) "开" else "关"
        }
        syncToggles()
        btnBall.setOnClickListener {
            val next = !Prefs.ballEnabled(this)
            Prefs.sp(this).edit().putBoolean(Prefs.KEY_BALL, next).apply()
            KwaiBallService.instance?.refreshBall() ?: toast("请先开启无障碍服务")
            syncToggles()
        }
        btnAuto.setOnClickListener {
            val next = !Prefs.autoEnabled(this)
            Prefs.sp(this).edit().putBoolean(Prefs.KEY_AUTO, next).apply()
            syncToggles()
        }

        findViewById<Button>(R.id.btnRefill).setOnClickListener { refillMissing() }
        findViewById<Button>(R.id.btnExportJson).setOnClickListener { export("json") }
        findViewById<Button>(R.id.btnExportCsv).setOnClickListener { export("csv") }
        findViewById<Button>(R.id.btnClear).setOnClickListener {
            lifecycleScope.launch(Dispatchers.IO) { dao.clear() }
        }

        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                dao.observeAll().collect { list ->
                    adapter.submitRecords(list)
                    refreshStatus(list.size)
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        lifecycleScope.launch(Dispatchers.IO) { refreshStatus(dao.all().size) }
    }

    private suspend fun refreshStatus(count: Int) {
        val ok = accessibilityEnabled()
        val text = buildString {
            append(if (ok) "无障碍服务已开启 · " else "无障碍服务未开启 · ")
            append("共 $count 条记录")
        }
        withContext(Dispatchers.Main) {
            tvStatus.text = text
            tvEmpty.visibility = if (count == 0) View.VISIBLE else View.GONE
        }
    }

    private fun accessibilityEnabled(): Boolean {
        val am = getSystemService(ACCESSIBILITY_SERVICE) as AccessibilityManager
        val expected = "$packageName/${KwaiBallService::class.java.name}"
        return am.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_ALL_MASK)
            .any { it.id == expected }
    }

    private fun askNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            requestNoti.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    // ---------- 补全历史记录里缺的封面 / 作者 ----------
    private fun refillMissing() {
        lifecycleScope.launch {
            val api = Prefs.apiTemplate(this@MainActivity)
            val targets = withContext(Dispatchers.IO) {
                dao.all().filter { it.coverUrl.isBlank() || it.authorName.isBlank() }
            }
            if (targets.isEmpty()) {
                toast("没有需要补全的记录")
                return@launch
            }
            toast("正在补全 ${targets.size} 条…")
            var ok = 0
            withContext(Dispatchers.IO) {
                targets.forEach { r ->
                    val d = runCatching { DetailResolver.resolve(r.videoUrl, api, r.videoId) }
                        .getOrNull() ?: return@forEach
                    dao.update(
                        r.copy(
                            title = d.title.ifBlank { r.title },
                            authorName = d.authorName.ifBlank { r.authorName },
                            authorId = d.authorId.ifBlank { r.authorId },
                            profileUrl = d.profileUrl.ifBlank { r.profileUrl },
                            coverUrl = d.coverUrl.ifBlank { r.coverUrl },
                            avatarUrl = d.avatarUrl.ifBlank { r.avatarUrl }
                        )
                    )
                    ok++
                }
            }
            toast(if (ok > 0) "已补全 $ok 条" else "补全失败，可能触发了风控，稍后再试")
        }
    }

    // ---------- 导出 ----------
    private fun export(kind: String) {
        lifecycleScope.launch {
            val list = withContext(Dispatchers.IO) { dao.all() }
            if (list.isEmpty()) {
                toast("还没有记录")
                return@launch
            }
            val dir = File(getExternalFilesDir(null), "export").apply { mkdirs() }
            val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.CHINA).format(Date())
            val file = File(dir, "kwaiclip_$stamp.$kind")
            withContext(Dispatchers.IO) {
                file.writeText(
                    if (kind == "json") toJson(list) else toCsv(list),
                    Charsets.UTF_8
                )
            }
            val uri: Uri = FileProvider.getUriForFile(
                this@MainActivity, "$packageName.fileprovider", file
            )
            val send = Intent(Intent.ACTION_SEND).apply {
                type = if (kind == "json") "application/json" else "text/csv"
                putExtra(Intent.EXTRA_STREAM, uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            startActivity(Intent.createChooser(send, "导出 $kind"))
        }
    }

    private fun toJson(list: List<Record>): String {
        val arr = JSONArray()
        list.forEach { r ->
            arr.put(
                JSONObject().apply {
                    put("watchTime", formatTime(r.watchTime))
                    put("videoId", r.videoId)
                    put("videoUrl", r.videoUrl)
                    put("title", r.title)
                    put("authorName", r.authorName)
                    put("authorId", r.authorId)
                    put("profileUrl", r.profileUrl)
                    put("coverUrl", r.coverUrl)
                    put("avatarUrl", r.avatarUrl)
                }
            )
        }
        return arr.toString(2)
    }

    private fun toCsv(list: List<Record>): String {
        fun esc(s: String) = "\"" + s.replace("\"", "\"\"") + "\""
        val sb = StringBuilder()
        sb.append('\uFEFF') // Excel 中文 BOM
        sb.append("观看时间,视频ID,视频地址,标题,作者,作者ID,主页地址,封面,头像\n")
        list.forEach { r ->
            sb.append(
                listOf(
                    formatTime(r.watchTime), r.videoId, r.videoUrl, r.title,
                    r.authorName, r.authorId, r.profileUrl, r.coverUrl, r.avatarUrl
                ).joinToString(",") { esc(it) }
            ).append('\n')
        }
        return sb.toString()
    }

    private fun toast(msg: String) =
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
}
