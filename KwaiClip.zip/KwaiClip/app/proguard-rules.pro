# 本项目默认不开启混淆（isMinifyEnabled=false），保留默认规则即可。
-keep class com.yuanbao.kwaiclip.data.** { *; }
